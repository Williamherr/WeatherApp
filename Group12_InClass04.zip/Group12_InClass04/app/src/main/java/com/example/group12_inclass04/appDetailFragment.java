package com.example.group12_inclass04;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;


public class appDetailFragment extends Fragment {
    IListener mListen;
    DataServices.App app;
    TextView appName,artistName,releaseDate;
    ListView listView;
    ArrayAdapter<String> adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_app_detail, container, false);
        appName = view.findViewById(R.id.appDetailApp);
        artistName = view.findViewById(R.id.appDetailArtist);
        releaseDate = view.findViewById(R.id.appDetailDate);
        listView = view.findViewById(R.id.appDetailListView);
        app = mListen.getDetailApp();
        appName.setText(app.name);
        artistName.setText(app.artistName);
        releaseDate.setText(app.releaseDate);

        adapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, android.R.id.text1,app.genres);
        listView.setAdapter(adapter);

        return view;
    }
    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof LoginFragment.IListener) {
            mListen = (IListener)context;
        }
    }

    public interface IListener {
        DataServices.App getDetailApp();
    }
}


package com.example.group12_inclass04;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class RegisterFragment extends Fragment {

    private String name;
    private String email;
    private String password;
    Button submit;
    EditText nameView, emailView,passwordView;
    TextView cancel;
    IListener mListen;
    DataServices.Account account;
    Toast toast;
    String token;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_register, container, false);
        Log.d("reg","onCreateView");
        submit = view.findViewById(R.id.ResigterSubmit);
        nameView = view.findViewById(R.id.RegisterName);
        emailView = view.findViewById(R.id.RegisterEmail);
        passwordView = view.findViewById(R.id.RegisterPassword);
        cancel = view.findViewById(R.id.RegisterCancel);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("reg","submit: onClick");

                // Validator
                DataServices.register(nameView.getText().toString(),emailView.getText().toString(), passwordView.getText().toString(), new DataServices.AuthResponse() {
                    @Override
                    public void onSuccess(String tok) {
                        token = tok;
                        Log.d("LoginFragment", token);
                    }
                    @Override
                    public void onFailure(DataServices.RequestException exception) {
                        Log.d("LoginFragment", exception.getMessage());
                        if (toast != null) {
                            Log.d("LoginFragment", "Cancel Toast");
                            toast.cancel();
                        }
                        toast = Toast.makeText(getContext(),exception.getMessage(),Toast.LENGTH_LONG);
                        toast.show();
                    }
                });

                DataServices.getAccount(token, new DataServices.AccountResponse() {
                    @Override
                    public void onSuccess(DataServices.Account acc) {
                        Log.d("LoginFragment",acc.toString());
                        account = acc;
                    }

                    @Override
                    public void onFailure(DataServices.RequestException exception) {
                        Log.d("LoginFragment","fail");
                    }
                });

                //Registers the account
                if (account == null)
                    return;
                Log.d("reg","Returning Account: " + account);
                nameView.setText("");
                emailView.setText("");
                passwordView.setText("");
                mListen.registerAccount(account, token);
            }
        });

        //cancel button
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("reg","cancel: onClick");
                nameView.setText("");
                emailView.setText("");
                passwordView.setText("");
                mListen.cancelRegister();
            }
        });
        return view;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof LoginFragment.IListener) {
            mListen = (IListener)context;
        }
        else {
            Log.d("reg","NOT WORK");
        }
    }

    public interface IListener{
        void registerAccount(DataServices.Account account,String token);
        void cancelRegister();

    }
}
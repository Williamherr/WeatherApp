package com.example.group12_inclass04;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;


public class AppCategoriesFragment extends Fragment {


    public AppCategoriesFragment() {
        // Required empty public constructor
    }
    TextView welcome;
    ListView listView;
    DataServices.Account acc;
    String token, category;
    ArrayAdapter<String> adapter;
    IListener mListen;
    Button logoutButton;
    Toast toast;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_app_categories, container, false);
        Log.d("AppCategory", "AppCategory : OnCreateView");
        acc = mListen.getAccount();
        token = mListen.getToken();
        logoutButton = view.findViewById(R.id.logoutButton);
        welcome = view.findViewById(R.id.welcome);
        Log.d("AppCategory", "Account: " + acc.toString());
        Log.d("AppCategory", "Token: " + token);
        welcome.setText(welcome.getText() + " " + acc.getName());
        listView = view.findViewById(R.id.ListView);
        category = "";


        // Getting Categories for ListView
        DataServices.getAppCategories(token, new DataServices.DataResponse<String>() {
            @Override
            public void onSuccess(ArrayList<String> data) {
                Log.d("AppCategory", data.toString());
                adapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, android.R.id.text1,data);
                listView.setAdapter(adapter);

            }

            @Override
            public void onFailure(DataServices.RequestException exception) {
                Log.d("AppCategory", exception.getMessage());
                if (toast != null) {
                    Log.d("AppCategory", "Cancel Toast");
                    toast.cancel();
                }
                toast = Toast.makeText(getContext(),exception.getMessage(),Toast.LENGTH_SHORT);
                toast.show();
            }
        });

        //Logout Button
        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListen.logout();

            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                category = adapter.getItem(position);
                Log.d("AppCategory", "Category: " + category);
                mListen.goToAppList(token,category);
            }
        });


        return view;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof LoginFragment.IListener) {
            mListen = (IListener)context;
        }
    }

    public interface IListener{
        DataServices.Account getAccount();
        String getToken();
        void logout();
        void goToAppList(String token, String category);
    }
}
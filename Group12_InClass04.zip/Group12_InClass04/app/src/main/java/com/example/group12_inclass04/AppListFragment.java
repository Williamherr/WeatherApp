package com.example.group12_inclass04;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link AppListFragment#newInstance} factory method to
 * create an instance of this fragment.
 *
 */
public class AppListFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "token";
    private static final String ARG_PARAM2 = "category";

    // TODO: Rename and change types of parameters
    private String token;
    private String category;
    ListView listView;
    AppAdapter adapter;
    IListener mListen;


    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param token Parameter 1.
     * @param category Parameter 2.
     * @return A new instance of fragment AppListFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static AppListFragment newInstance(String token, String category) {
        AppListFragment fragment = new AppListFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, token);
        args.putString(ARG_PARAM2, category);
        fragment.setArguments(args);
        return fragment;
    }

    public AppListFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            token = getArguments().getString(ARG_PARAM1);
            category = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        Log.d("AppListFrag", "onCreateView");
        Log.d("AppListFrag", "Category: " + category + ", Token: " + token);
        View view = inflater.inflate(R.layout.fragment_app_list, container, false);
        listView = view.findViewById(R.id.appListView);
        getApps();

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                DataServices.App app = adapter.getItem(position);
                Log.d("AppListFrag", app.toString());
                mListen.goToAppDetails(app);
            }
        });


        Log.d("AppListFrag", "Returning view");
        return view;
    }


    public void getApps() {
        DataServices.getAppsByCategory(token, category, new DataServices.DataResponse<DataServices.App>() {
            @Override
            public void onSuccess(ArrayList<DataServices.App> data) {
                Log.d("AppListFrag", "onSucess");
                adapter = new AppAdapter(getContext(), R.layout.app_list,data);
                listView.setAdapter(adapter);
            }

            @Override
            public void onFailure(DataServices.RequestException exception) {
                Log.d("AppListFrag", "onFailure");
            }
        });
    }

    public class AppAdapter extends ArrayAdapter<DataServices.App> {

        DataServices.App apps;

        public AppAdapter(@NonNull Context context, int resource, @NonNull List<DataServices.App> objects) {
            super(context, resource, objects);
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.app_list, parent, false);
            }
            apps = getItem(position);

            TextView app = convertView.findViewById(R.id.appName);
            TextView artist = convertView.findViewById(R.id.artistName);
            TextView date = convertView.findViewById(R.id.releaseDate);

            app.setText(apps.name);
            artist.setText(apps.artistName);
            date.setText(apps.releaseDate);
            return convertView;
        }
    }
    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof LoginFragment.IListener) {
            mListen = (IListener)context;
        }
    }

    public interface IListener {
        void goToAppDetails(DataServices.App app);
    }
}
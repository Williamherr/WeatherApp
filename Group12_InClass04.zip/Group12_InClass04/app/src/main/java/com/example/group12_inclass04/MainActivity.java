package com.example.group12_inclass04;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity implements LoginFragment.IListener, RegisterFragment.IListener, AppCategoriesFragment.IListener,AppListFragment.IListener, appDetailFragment.IListener {

    LoginFragment loginFragment;
    RegisterFragment registerFragment;
    AppCategoriesFragment appCategoriesFragment;
    AppListFragment appListFragment;
    appDetailFragment appDetailFragment;
    DataServices.App apps;
    DataServices.Account account;
    String token;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d("Main", "OnCreate");
        loginFragment = new LoginFragment();
        registerFragment = new RegisterFragment();
        appCategoriesFragment = new AppCategoriesFragment();
        appListFragment = new AppListFragment();
        appDetailFragment = new appDetailFragment();

        setTitle(R.string.Login);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragmentContainerView,loginFragment)
                .commit();
    }
    //Login Fragment
    //Login Button
    @Override
    public void loginUser(DataServices.Account account, String token) {
        Log.d("Main", "Login User");
        this.account = account;
        this.token = token;
        setTitle(getString(R.string.Account));
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragmentContainerView,appCategoriesFragment)
                .commit();
    }
    // Create New Account
    @Override
    public void newAccount() {
        setTitle(getString(R.string.RegisterAccount));
        Log.d("Main", "New Account");
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragmentContainerView,registerFragment)
                .commit();
    }

    // Register Fragment
    // Submit Button
    @Override
    public void registerAccount(DataServices.Account account, String token) {
        Log.d("Main", "Registered Account");
        this.account = account;
        this.token = token;
        setTitle(getString(R.string.AppCategoriesFragment));
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragmentContainerView,appCategoriesFragment)
                .commit();
    }
    //Cancel Button
    @Override
    public void cancelRegister() {
        setTitle(getString(R.string.Login));
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragmentContainerView,loginFragment)
                .commit();
    }
    //AppCategoriesFragment
    // Gets the Account
    @Override
    public DataServices.Account getAccount() {
        Log.d("Main", account.toString());
        return account;
    }
    // Gets the Token
    @Override
    public String getToken() {
        Log.d("Main",token);
        return token;
    }
    // Logout Button
    @Override
    public void logout() {
        this.account = null;
        this.token = "";
        apps = null;
        cancelRegister();
    }
    // Go to the category list (AppListFragment)
    @Override
    public void goToAppList(String token, String category) {
        Log.d("Main", "Going to AppListFragment");
        setTitle(category);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragmentContainerView,appListFragment.newInstance(token,category))
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void goToAppDetails(DataServices.App app) {
        Log.d("Main", "Going to AppListDetails");
        this.apps = app;
        setTitle(R.string.appDetails);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragmentContainerView,appDetailFragment)
                .addToBackStack(null)
                .commit();
    }

    @Override
    public DataServices.App getDetailApp() {
        return apps;
    }
}
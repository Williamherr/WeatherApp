package com.example.group12_inclass04;

import android.accounts.AccountManager;
import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashMap;
import java.util.Map;


public class LoginFragment extends Fragment{

    // TODO: Rename and change types of parameters

    EditText emailView;
    EditText passwordView;
    TextView newAccount;
    Button loginButton;
    IListener mListen;
    DataServices.Account account;
    Toast toast;
    String token;

    public LoginFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        Log.d("LoginFragment", "onCreateView");
        View view = inflater.inflate(R.layout.fragment_login, container, false);
        emailView = view.findViewById(R.id.loginEmail);
        passwordView = view.findViewById(R.id.loginPassword);
        loginButton = view.findViewById(R.id.loginButton);
        newAccount = view.findViewById(R.id.newAccountView);
        account = null;
        token = "";

        // Login Button
        loginButtonClicked();

        // New Account Button
        newAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("LoginFragment", "New Account");
                //calls the interface for a new account
                mListen.newAccount();
            }
        });

        return view;
    }

    public void loginButtonClicked() {
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("LoginFragment", "Email: " + emailView.getText().toString());
                Log.d("LoginFragment", "Password: " + passwordView.getText().toString());
                //Login Method for DataService
                 DataServices.login(emailView.getText().toString(), passwordView.getText().toString(), new DataServices.AuthResponse() {
                    @Override
                    public void onSuccess(String tok) {
                        Log.d("LoginFragment", tok);
                        token = tok;
                        DataServices.getAccount(token, new DataServices.AccountResponse() {
                            @Override
                            public void onSuccess(DataServices.Account acc) {
                                Log.d("LoginFragment",acc.toString());
                                account = acc;
                            }

                            @Override
                            public void onFailure(DataServices.RequestException exception) {
                                Log.d("LoginFragment","fail");
                            }
                        });
                    }

                    @Override
                    public void onFailure(DataServices.RequestException exception) {
                        Log.d("LoginFragment", exception.getMessage());
                        if (toast != null) {
                            Log.d("LoginFragment", "Cancel Toast");
                            toast.cancel();
                        }
                        toast = Toast.makeText(getContext(),exception.getMessage(),Toast.LENGTH_LONG);
                        toast.show();
                    }
                });

                if (account == null)
                    return;

                //calls the interface and passes account to the main
                emailView.getText().clear();
                passwordView.getText().clear();

                mListen.loginUser(account, token);
                Log.d("LoginFragment", "Account: " + account);
                Log.d("LoginFragment", "Token: " + token);

            }
        });
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof IListener) {
            mListen = (IListener)context;
        }
    }

    public interface IListener{
        void loginUser(DataServices.Account account, String token);
        void newAccount();
    }
}

